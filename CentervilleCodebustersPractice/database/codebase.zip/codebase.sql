-- phpMyAdmin SQL Dump
-- version 5.2.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Nov 30, 2023 at 07:50 PM
-- Server version: 10.4.24-MariaDB
-- PHP Version: 8.1.6

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `codebase`
--

-- --------------------------------------------------------

--
-- Table structure for table `quotes`
--

CREATE TABLE `quotes` (
  `id` int(11) NOT NULL,
  `quote` varchar(1000) NOT NULL,
  `quoted` varchar(255) NOT NULL,
  `fastestTime` double NOT NULL DEFAULT 1000
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `quotes`
--

INSERT INTO `quotes` (`id`, `quote`, `quoted`, `fastestTime`) VALUES
(1, 'You must be the change you wish to see in the world', 'Mahatma Gandhi', 1000),
(2, 'The greatest glory in living lies not in never falling, but in rising every time we fall', 'Nelson Mandela', 1000),
(3, 'The way to get started is to quit talking and begin doing', 'Walt Disney', 1000),
(4, 'The future belongs to those who believe in the beauty of their dreams', 'Eleanor Roosevelt', 1000),
(5, 'If you set your goals ridiculously high and it\'s a failure, you will fail above everyone else\'s success', 'James Cameron', 1000),
(6, 'Spread love everywhere you go. Let no one ever come to you without leaving happier', 'Mother Teresa', 1000),
(7, 'The only thing we have to fear is fear itself', 'Franklin D. Roosevelt', 1000),
(8, 'Darkness cannot drive out darkness: only light can do that. Hate cannot drive out hate: only love can do that', 'Martin Luther King Jr.', 1000),
(9, 'Do one thing every day that scares you', 'Eleanor Roosevelt', 1000),
(10, 'Well done is better than well said', 'Benjamin Franklin', 1000),
(11, 'The best and most beautiful things in the world cannot be seen or even touched - they must be felt with the heart', 'Helen Keller', 1000),
(12, 'It is during our darkest moments that we must focus to see the light', 'Aristotle', 1000),
(13, 'Do not go where the path may lead, go instead where there is no path and leave a trail', 'Ralph Waldo Emerson', 1000),
(14, 'Be yourself; everyone else is already taken', 'Oscar Wilde', 1000),
(15, 'If life were predictable it would cease to be life and be without flavor', 'Eleanor Roosevelt', 1000),
(16, 'In the end, it\'s not the years in your life that count. It\'s the life in your years', 'Abraham Lincoln', 1000),
(17, 'You will face many defeats in life, but never let yourself be defeated', 'Maya Angelou', 1000),
(18, 'Never let the fear of striking out keep you from playing the game', 'Babe Ruth', 1000),
(19, 'Life is never fair, and perhaps it is a good thing for most of us that it is not', 'Oscar Wilde', 1000),
(20, 'The only impossible journey is the one you never begin', 'Tony Robbins', 1000),
(21, 'In this life we cannot do great things. We can only do small things with great love', 'Mother Teresa', 1000),
(22, 'Only a life lived for others is a life worthwhile', 'Albert Einstein', 1000),
(23, 'You may say I\'m a dreamer, but I\'m not the only one. I hope someday you\'ll join us. And the world will live as one.', 'John Lennon', 1000),
(24, 'You only live once, but if you do it right, once is enough', 'Mae West', 1000),
(25, 'Don\'t worry when you are not recognized, but strive to be worthy of recognition', 'Abraham Lincoln', 1000),
(26, 'Life is really simple, but we insist on making it complicated', 'Confucius', 1000),
(27, 'May you live all the days of your life', 'Jonathan Swift', 1000),
(28, 'Life itself is the most wonderful fairy tale', 'Hans Christian Andersen', 1000),
(29, '\"Do not let making a living prevent you from making a life', 'John Wooden', 1000),
(30, 'Go confidently in the direction of your dreams! Live the life you\'ve imagined', 'Henry David Thoreau', 1000),
(31, 'Life is either a daring adventure or nothing', 'Helen Keller', 1000),
(32, 'In three words I can sum up everything I\'ve learned about life: it goes on', 'Robert Frost', 1000),
(33, 'You have brains in your head. You have feet in your shoes. You can steer yourself any direction you choose', 'Dr. Seuss', 1000),
(34, 'Life is made of ever so many partings welded together', 'Charles Dickens', 1000),
(35, 'Life is trying things to see if they work', 'Ray Bradbury', 1000),
(36, 'Keep smiling, because life is a beautiful thing and there\'s so much to smile about', 'Marilyn Monroe', 1000),
(37, 'In the depth of winter, I finally learned that within me there lay an invincible summer', 'Albert Camus', 1000),
(38, 'So we beat on, boats against the current, borne back ceaselessly into the past', 'F. Scott Fitzgerald', 1000),
(39, 'All that is gold does not glitter,\r\nNot all those who wander are lost', 'J.R.R. Tolkien', 1000),
(40, 'I don\'t know half of you half as well as I should like; and I like less than half of you half as well as you deserve', 'J.R.R. Tolkien', 1000),
(41, 'All we have to decide is what to do with the time that is given us', 'J.R.R. Tolkien', 1000),
(42, 'Two things are infinite: the universe and human stupidity; and I\'m not sure about the universe', 'Albert Einstein', 1000),
(43, 'A room without books is like a body without a soul', 'Marcus Tullius Cicero', 1000),
(44, 'Be who you are and say what you feel, because those who mind don\'t matter, and those who matter don\'t mind', 'Bernard M. Baruch', 1000),
(45, 'You know you\'re in love when you can\'t fall asleep because reality is finally better than your dreams', 'Dr. Seuss', 1000),
(46, 'If you want to know what a man\'s like, take a good look at how he treats his inferiors, not his equals.', 'J.K. Rowling', 1000),
(47, 'If you tell the truth, you don\'t have to remember anything', 'Mark Twain', 1000),
(48, 'A friend is someone who knows all about you and still loves you', 'Elbert Hubbard', 1000),
(49, 'Insanity is doing the same thing, over and over again, but expecting different results', 'Narcotics Anonymous', 1000),
(50, 'It is better to be hated for what you are than to be loved for what you are not', 'Andre Gide', 1000),
(51, 'The person, be it gentleman or lady, who has not pleasure in a good novel, must be intolerably stupid', 'Jane Austen', 1000),
(52, 'Imperfection is beauty, madness is genius and it\'s better to be absolutely ridiculous than absolutely boring', 'Marilyn Monroe', 1000),
(53, 'It does not do to dwell on dreams and forget to live', 'J.K. Rowling', 1000),
(54, 'We are all in the gutter, but some of us are looking at the stars', 'Oscar Wilde', 1000);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `quotes`
--
ALTER TABLE `quotes`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `quotes`
--
ALTER TABLE `quotes`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=55;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
